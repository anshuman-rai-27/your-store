# Vercel deployment example

The deployment example has moved to https://github.com/prisma/deployment-example-vercel

[Deployment guide](https://www.prisma.io/docs/guides/deployment/deploying-to-vercel)