#!/bin/sh

set -eu

npm install
npm run test
