# GraphQL Server Example with `express-graphql`

[`express-graphql`](https://github.com/graphql/express-graphql) has been deprecated. 

We recommend checking out the [`graphql`](../graphql) example that uses [GraphQL Yoga](https://the-guild.dev/graphql/yoga-server) as the GraphQL server and [Pothos](https://pothos-graphql.dev/) for code-first schema definition.