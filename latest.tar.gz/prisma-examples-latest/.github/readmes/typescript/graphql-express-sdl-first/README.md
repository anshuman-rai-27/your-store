# GraphQL Server Example with `express-graphql` (SDL-first)

[`express-graphql`](https://github.com/graphql/express-graphql) has been deprecated. 

We recommend checking out the [`graphql-sdl-first`](../graphql-sdl-first) example that uses [GraphQL Yoga](https://the-guild.dev/graphql/yoga-server) as the GraphQL server.