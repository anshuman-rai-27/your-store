## Getting started

### 1. Download example and install dependencies

Download this example:

```